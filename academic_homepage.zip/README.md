# 学术主页（基于 acad-homepage 设计的静态版）

这是用 [acad-homepage](https://github.com/RayeRen/acad-homepage.github.io) 的视觉风格做的**纯静态单页学术主页**。
相比原版 Jekyll 模板，它的好处是：

- 双击 `index.html` 即可在浏览器预览，**无需安装 Ruby / Jekyll**
- 整个目录直接丢到任意静态托管（GitHub Pages / Vercel / 自己的服务器）即可上线
- 所有内容都在一个文件里，改起来直观

> 如果你之后想要原版 Jekyll 模板的「Google Scholar 引用数自动更新」等高级功能，
> 见本文末尾的「升级到原版 Jekyll 模板」。

---

## 文件结构

```
/workspace
├── index.html   # 整站（结构 + 样式 + 内容都在这里）
└── README.md    # 本说明
```

> 头像、论文配图目前用内联 SVG 占位。换成真实图片时，把 `index.html` 里对应的
> `src="data:image/svg+xml,..."` 改成 `src="images/avatar.jpg"` 这样的路径，
> 并把图片放进同级的 `images/` 文件夹即可。

---

## 如何替换成你自己的内容

打开 `index.html`，按下面的位置改：

| 你要改什么 | 在文件里搜这个 | 说明 |
|---|---|---|
| 网页标题 / 浏览器标签 | `<title>` | 改成「你的姓名 \| 学术主页」 |
| 顶部站点名 | `class="site-title"` | 改成你的名字 |
| 导航项 | `<header class="masthead">` | 增删 `<a href="#id">` 即可 |
| 头像 | `class="author__avatar"` 的 `<img>` | 换 `src` |
| 姓名 / 职称 / 城市 | `author__name` / `author__bio` / `author__loc` | 直接改文字 |
| 社交链接 | `author__social` | 保留你需要的，删掉不用的；把链接换成你的 |
| 简历按钮 | `author__cv` | 把 `href="#"` 换成你的 CV 文件 |
| 自我介绍 | `id="about-me"` 段落 | 改成你的介绍 |
| Theses（原 Publications） | `id="theses"`，卡片式 `class="paper-box"`，列表式 `class="pub-list"` | 改标题 / 作者 / 链接 / 配图 / badge |
| 荣誉 | `id="honors"` | 每条一行 |
| 教育 | `id="education"` | 每条一行 |
| 实习 / 经历 | `id="internships"` | 每条一行 |
| 爱好与技能 | `id="hobbies"` | Hobbies 用列表，Skills 用 `.skill` 标签 |

页面已全英文，每个区块都有英文注释标好了替换点，照着改就行。

---

## 部署到 GitHub Pages

1. 在 GitHub 新建仓库，命名为 `你的用户名.github.io`
2. 把 `index.html`（以及 `images/` 若有）推上去
3. 仓库 Settings → Pages → Source 选 `main` 分支根目录
4. 等一两分钟，访问 `https://你的用户名.github.io` 即可

（也可以部署到 Vercel / Netlify / 任意静态空间，直接拖文件夹上传。）

---

## 升级到原版 Jekyll 模板（含 GS 自动统计）

如果你想要原版模板的「Fork 即自动更新引用数」能力：

1. Fork [RayeRen/acad-homepage.github.io](https://github.com/RayeRen/acad-homepage.github.io)
2. 重命名为 `你的用户名.github.io`
3. 在仓库 `Settings → Secrets → Actions` 添加 `GOOGLE_SCHOLAR_ID`
4. 本地装 Ruby + Jekyll 后 `bash run_server.sh` 预览，改 `_config.yml` 和 `_pages/about.md`
5. 推送后 GitHub Pages 自动构建

本静态版的模块划分（About / Theses / Honors / Education / Internships / Hobbies & Skills）
与原模板风格一致，页面内容已全英文，迁移时可直接对照替换。
